<template>
   <div class="toast">
   		该功能暂未开放
   </div>
</template>

<script>

export default {
  name: 'toast'
}
</script>


<style scoped>
	.toast {
		position: absolute;
		left: 50%;
		top: 1.8rem;
		z-index: 2;
		margin-left: -2rem;
		width: 4rem;
		line-height: 0.88rem;
		text-align: center;
		color: #fff;
		background: #60adfe;
	}
</style>